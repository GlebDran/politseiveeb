<?php
$kasutaja="root";
$parool="";
$andmebaas="politsei";
$serverinimi="localhost";
$conn = new mysqli($serverinimi, $kasutaja, $parool, $andmebaas);
$conn->set_charset("utf8");