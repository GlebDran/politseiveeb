-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Loomise aeg: Mai 22, 2025 kell 02:37 PL
-- Serveri versioon: 10.4.32-MariaDB
-- PHP versioon: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Andmebaas: `politsei`
--

-- --------------------------------------------------------

--
-- Tabeli struktuur tabelile `kasutajad`
--

CREATE TABLE `kasutajad` (
  `id` int(11) NOT NULL,
  `kasutajanimi` varchar(50) NOT NULL,
  `parool` varchar(255) NOT NULL,
  `roll` enum('admin','kasutaja') DEFAULT 'kasutaja'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Andmete tõmmistamine tabelile `kasutajad`
--

INSERT INTO `kasutajad` (`id`, `kasutajanimi`, `parool`, `roll`) VALUES
(2, 'Admin1', '$2y$10$dTKxY7ntRNLRvU48O9i0euBuLO8GieEvBVj6Wvee5KZfbvSQmTRj2', 'admin'),
(3, 'Gleb', '$2y$10$O9GXqsL5ZLTMzg7OHwwufOfoHPYDU8Ejre5VMC5C5cuhywsUZdlIm', 'kasutaja'),
(4, 'Irina', '$2y$10$yvOO5nt5RUIxONcBP0QvSe8utxh3wRjPpsiJrRAxog6m94RZ3Mm5G', 'admin'),
(5, 'Test', '$2y$10$KOwuIvTX8DdGhaNdMrmWVe/wyuIB0bXz8HfUYhLjlhrr9Pg.YpQTK', 'kasutaja');

-- --------------------------------------------------------

--
-- Tabeli struktuur tabelile `kuritegevus`
--

CREATE TABLE `kuritegevus` (
  `id` int(11) NOT NULL,
  `kuriteg_tyyp` varchar(50) NOT NULL,
  `kirjeldus` text NOT NULL,
  `kuupaev` date NOT NULL,
  `asukoht` varchar(100) DEFAULT NULL,
  `politseinik_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Andmete tõmmistamine tabelile `kuritegevus`
--

INSERT INTO `kuritegevus` (`id`, `kuriteg_tyyp`, `kirjeldus`, `kuupaev`, `asukoht`, `politseinik_id`) VALUES
(1, 'Vargus', 'Sissemurdmine korterisse', '2024-04-21', 'Tallinn', NULL),
(2, 'Rööv', 'Tänavarööv Mustamäel', '2024-05-02', 'Tallinn', NULL),
(3, 'Petuskeem', 'E-kirjadega raha väljapetmine', '2024-03-18', 'Tartu', NULL),
(4, 'Petuskeem', 'Telefon', '2025-05-22', 'Kopli', 1),
(6, 'Ugnal tachku', 'Berlingo', '2025-05-21', 'Lasnamae', 3),
(7, 'tappamine', 'Killer', '2025-05-22', 'Maardu', 1);

-- --------------------------------------------------------

--
-- Tabeli struktuur tabelile `kuriteo_kurjategija`
--

CREATE TABLE `kuriteo_kurjategija` (
  `kuritegevus_id` int(11) NOT NULL,
  `kurjategija_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Andmete tõmmistamine tabelile `kuriteo_kurjategija`
--

INSERT INTO `kuriteo_kurjategija` (`kuritegevus_id`, `kurjategija_id`) VALUES
(4, 2),
(6, 4),
(7, 5);

-- --------------------------------------------------------

--
-- Tabeli struktuur tabelile `kurjategija`
--

CREATE TABLE `kurjategija` (
  `id` int(11) NOT NULL,
  `nimi` varchar(50) NOT NULL,
  `pnimi` varchar(50) NOT NULL,
  `aadress` varchar(150) DEFAULT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `synnipaev` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Andmete tõmmistamine tabelile `kurjategija`
--

INSERT INTO `kurjategija` (`id`, `nimi`, `pnimi`, `aadress`, `telnumber`, `synnipaev`) VALUES
(1, 'Ivanov', 'Sergei', 'Pärnu mnt 21, Tallinn', '55512345', '1985-11-22'),
(2, 'Petrov', 'Andrei', 'Tartu tn 7, Tartu', '53445566', '1990-03-10'),
(3, 'Mets', 'Kadri', 'Sõpruse pst 18, Narva', '56789012', '1992-07-08'),
(4, 'Test', '', NULL, NULL, NULL),
(5, 'Zhan', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabeli struktuur tabelile `politseinik`
--

CREATE TABLE `politseinik` (
  `id` int(11) NOT NULL,
  `nimi` varchar(50) NOT NULL,
  `pnimi` varchar(50) NOT NULL,
  `auaste` varchar(30) DEFAULT NULL,
  `isikukood` varchar(20) DEFAULT NULL,
  `osakond_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Andmete tõmmistamine tabelile `politseinik`
--

INSERT INTO `politseinik` (`id`, `nimi`, `pnimi`, `auaste`, `isikukood`, `osakond_id`) VALUES
(1, 'Gleb', 'Dranitsõn', 'Lipnik', '39404190252', 3),
(2, 'Irina', 'Merkulova', 'Kindrall', '49494111321', 2),
(3, 'Anna', 'Oleks', 'Reamees', '49394395954', 4);

-- --------------------------------------------------------

--
-- Tabeli struktuur tabelile `politseiosakond`
--

CREATE TABLE `politseiosakond` (
  `id` int(11) NOT NULL,
  `nimi` varchar(100) NOT NULL,
  `aadress` varchar(150) DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `linn` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Andmete tõmmistamine tabelile `politseiosakond`
--

INSERT INTO `politseiosakond` (`id`, `nimi`, `aadress`, `telefon`, `linn`) VALUES
(1, 'Kesklinna jaoskond', 'Tartu mnt 85', '6123000', 'Tallinn'),
(2, 'Lasnamäe jaoskond', 'Punane tn 69', '6124000', 'Tallinn'),
(3, 'Põhja-Tallinna jaoskond', 'Kopli tn 76', '6125000', 'Tallinn'),
(4, 'Mustamäe jaoskond', 'Sõpruse pst 250', '6126000', 'Tallinn'),
(5, 'Nõmme jaoskond', 'Pärnu mnt 388', '6127000', 'Tallinn');

--
-- Indeksid tõmmistatud tabelitele
--

--
-- Indeksid tabelile `kasutajad`
--
ALTER TABLE `kasutajad`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kasutajanimi` (`kasutajanimi`);

--
-- Indeksid tabelile `kuritegevus`
--
ALTER TABLE `kuritegevus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `politseinik_id` (`politseinik_id`);

--
-- Indeksid tabelile `kuriteo_kurjategija`
--
ALTER TABLE `kuriteo_kurjategija`
  ADD PRIMARY KEY (`kuritegevus_id`,`kurjategija_id`),
  ADD KEY `kurjategija_id` (`kurjategija_id`);

--
-- Indeksid tabelile `kurjategija`
--
ALTER TABLE `kurjategija`
  ADD PRIMARY KEY (`id`);

--
-- Indeksid tabelile `politseinik`
--
ALTER TABLE `politseinik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isikukood` (`isikukood`),
  ADD KEY `osakond_id` (`osakond_id`);

--
-- Indeksid tabelile `politseiosakond`
--
ALTER TABLE `politseiosakond`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT tõmmistatud tabelitele
--

--
-- AUTO_INCREMENT tabelile `kasutajad`
--
ALTER TABLE `kasutajad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT tabelile `kuritegevus`
--
ALTER TABLE `kuritegevus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT tabelile `kurjategija`
--
ALTER TABLE `kurjategija`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT tabelile `politseinik`
--
ALTER TABLE `politseinik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT tabelile `politseiosakond`
--
ALTER TABLE `politseiosakond`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tõmmistatud tabelite piirangud
--

--
-- Piirangud tabelile `kuritegevus`
--
ALTER TABLE `kuritegevus`
  ADD CONSTRAINT `kuritegevus_ibfk_1` FOREIGN KEY (`politseinik_id`) REFERENCES `politseinik` (`id`);

--
-- Piirangud tabelile `kuriteo_kurjategija`
--
ALTER TABLE `kuriteo_kurjategija`
  ADD CONSTRAINT `kuriteo_kurjategija_ibfk_1` FOREIGN KEY (`kuritegevus_id`) REFERENCES `kuritegevus` (`id`),
  ADD CONSTRAINT `kuriteo_kurjategija_ibfk_2` FOREIGN KEY (`kurjategija_id`) REFERENCES `kurjategija` (`id`);

--
-- Piirangud tabelile `politseinik`
--
ALTER TABLE `politseinik`
  ADD CONSTRAINT `politseinik_ibfk_1` FOREIGN KEY (`osakond_id`) REFERENCES `politseiosakond` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
