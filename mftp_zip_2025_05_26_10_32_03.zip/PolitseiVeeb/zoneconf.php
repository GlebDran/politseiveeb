<?php
$servernimi="d133842.mysql.zonevs.eu";
$kasutaja="d133842_glebdran";
$parool="234262247Wifi";
$andmebaas="d133842_phpbaas";

$yhendus = new mysqli($servernimi,$kasutaja,$parool,$andmebaas);
$conn = $yhendus;
$yhendus->set_charset("utf8");
if ($yhendus->connect_error) {
    die("Andmebaasiühenduse viga: " . $yhendus->connect_error);
}?>